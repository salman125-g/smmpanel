import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import StatsCard from "@/components/stats-card";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats/user"],
    retry: false,
  });

  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ["/api/orders"],
    retry: false,
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const recentOrders = orders?.slice(0, 3) || [];

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: "secondary",
      processing: "outline",
      completed: "default",
      cancelled: "destructive",
    } as const;

    return (
      <Badge variant={variants[status as keyof typeof variants] || "secondary"}>
        {status}
      </Badge>
    );
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <Header />
        
        <div className="p-6" data-testid="dashboard-content">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900" data-testid="text-dashboard-title">
              Dashboard
            </h2>
            <p className="mt-2 text-gray-600" data-testid="text-dashboard-description">
              Welcome back! Here's your account overview.
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard
              icon="fas fa-chart-line"
              title="Total Orders"
              value={statsLoading ? "..." : stats?.totalOrders?.toString() || "0"}
              bgColor="bg-blue-100"
              iconColor="text-blue-600"
              data-testid="card-total-orders"
            />
            <StatsCard
              icon="fas fa-clock"
              title="Pending Orders"
              value={statsLoading ? "..." : stats?.pendingOrders?.toString() || "0"}
              bgColor="bg-yellow-100"
              iconColor="text-yellow-600"
              data-testid="card-pending-orders"
            />
            <StatsCard
              icon="fas fa-check-circle"
              title="Completed"
              value={statsLoading ? "..." : stats?.completedOrders?.toString() || "0"}
              bgColor="bg-green-100"
              iconColor="text-green-600"
              data-testid="card-completed-orders"
            />
            <StatsCard
              icon="fas fa-money-bill-wave"
              title="Total Spent"
              value={statsLoading ? "..." : `PKR ${stats?.totalSpent || "0.00"}`}
              bgColor="bg-purple-100"
              iconColor="text-purple-600"
              data-testid="card-total-spent"
            />
          </div>

          {/* Recent Orders & Quick Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Recent Orders */}
            <Card data-testid="card-recent-orders">
              <CardHeader>
                <CardTitle>Recent Orders</CardTitle>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    ))}
                  </div>
                ) : recentOrders.length > 0 ? (
                  <div className="space-y-4">
                    {recentOrders.map((order) => (
                      <div key={order.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg" data-testid={`order-${order.id}`}>
                        <div>
                          <p className="font-medium text-gray-900" data-testid={`text-order-service-${order.id}`}>
                            {order.service.name}
                          </p>
                          <p className="text-sm text-gray-600" data-testid={`text-order-id-${order.id}`}>
                            Order #{order.id.slice(-8)}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900" data-testid={`text-order-cost-${order.id}`}>
                            PKR {order.totalCost}
                          </p>
                          {getStatusBadge(order.status)}
                        </div>
                      </div>
                    ))}
                    <div className="mt-4">
                      <a href="/orders" className="text-primary hover:text-blue-800 text-sm font-medium" data-testid="link-view-all-orders">
                        View all orders →
                      </a>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8" data-testid="empty-orders">
                    <i className="fas fa-shopping-cart text-4xl text-gray-300 mb-4"></i>
                    <p className="text-gray-500 mb-4">No orders yet</p>
                    <Button onClick={() => window.location.href = '/services'} data-testid="button-place-first-order">
                      Place Your First Order
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card data-testid="card-quick-actions">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button 
                    className="w-full justify-between h-auto p-4" 
                    onClick={() => window.location.href = '/services'}
                    data-testid="button-place-new-order"
                  >
                    <div className="flex items-center">
                      <i className="fas fa-plus mr-3"></i>
                      <span className="font-medium">Place New Order</span>
                    </div>
                    <i className="fas fa-arrow-right"></i>
                  </Button>
                  
                  <Button 
                    variant="secondary" 
                    className="w-full justify-between h-auto p-4 bg-accent text-white hover:bg-green-700"
                    onClick={() => window.location.href = '/balance'}
                    data-testid="button-add-funds"
                  >
                    <div className="flex items-center">
                      <i className="fas fa-credit-card mr-3"></i>
                      <span className="font-medium">Add Funds</span>
                    </div>
                    <i className="fas fa-arrow-right"></i>
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-between h-auto p-4"
                    onClick={() => window.location.href = '/orders'}
                    data-testid="button-view-orders"
                  >
                    <div className="flex items-center">
                      <i className="fas fa-list mr-3"></i>
                      <span className="font-medium">View All Orders</span>
                    </div>
                    <i className="fas fa-arrow-right"></i>
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-between h-auto p-4"
                    onClick={() => window.location.href = '/profile'}
                    data-testid="button-account-settings"
                  >
                    <div className="flex items-center">
                      <i className="fas fa-user-cog mr-3"></i>
                      <span className="font-medium">Account Settings</span>
                    </div>
                    <i className="fas fa-arrow-right"></i>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
