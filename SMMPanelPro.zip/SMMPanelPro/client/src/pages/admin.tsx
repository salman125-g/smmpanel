import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import StatsCard from "@/components/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Admin() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && (!isAuthenticated || !user?.isAdmin)) {
      toast({
        title: "Unauthorized",
        description: "Admin access required. Redirecting...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = user ? "/" : "/api/login";
      }, 1000);
      return;
    }
  }, [isAuthenticated, isLoading, user, toast]);

  const { data: adminStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/admin/stats"],
    retry: false,
    enabled: !!user?.isAdmin,
  });

  const { data: apiProviders = [], isLoading: providersLoading } = useQuery({
    queryKey: ["/api/admin/providers"],
    retry: false,
    enabled: !!user?.isAdmin,
  });

  if (isLoading || !isAuthenticated || !user?.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Checking permissions...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <Header />
        
        <div className="p-6" data-testid="admin-content">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900" data-testid="text-admin-title">
              Admin Panel
            </h2>
            <p className="mt-2 text-gray-600" data-testid="text-admin-description">
              Manage APIs, services, and system settings.
            </p>
          </div>

          {/* Admin Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard
              icon="fas fa-users"
              title="Total Users"
              value={statsLoading ? "..." : adminStats?.totalUsers?.toString() || "0"}
              bgColor="bg-blue-100"
              iconColor="text-blue-600"
              data-testid="card-total-users"
            />
            <StatsCard
              icon="fas fa-chart-line"
              title="Active Services"
              value={statsLoading ? "..." : adminStats?.activeServices?.toString() || "0"}
              bgColor="bg-green-100"
              iconColor="text-green-600"
              data-testid="card-active-services"
            />
            <StatsCard
              icon="fas fa-cogs"
              title="API Providers"
              value={statsLoading ? "..." : adminStats?.apiProviders?.toString() || "0"}
              bgColor="bg-purple-100"
              iconColor="text-purple-600"
              data-testid="card-api-providers"
            />
            <StatsCard
              icon="fas fa-exclamation-triangle"
              title="Pending Orders"
              value={statsLoading ? "..." : adminStats?.pendingOrders?.toString() || "0"}
              bgColor="bg-yellow-100"
              iconColor="text-yellow-600"
              data-testid="card-pending-orders"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* API Management */}
            <Card data-testid="card-api-management">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>API Providers</CardTitle>
                  <Button data-testid="button-add-api-provider">
                    <i className="fas fa-plus mr-2"></i>
                    Add API
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {providersLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="animate-pulse">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                          <div className="flex-1">
                            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                            <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : apiProviders.length > 0 ? (
                  <div className="space-y-4">
                    {apiProviders.map((provider) => (
                      <div key={provider.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg" data-testid={`provider-${provider.id}`}>
                        <div className="flex items-center">
                          <div className={`w-10 h-10 ${provider.isActive ? 'bg-green-100' : 'bg-red-100'} rounded-lg flex items-center justify-center mr-4`}>
                            <i className={`fas ${provider.isActive ? 'fa-check text-green-600' : 'fa-times text-red-600'}`}></i>
                          </div>
                          <div>
                            <p className="font-medium text-gray-900" data-testid={`text-provider-name-${provider.id}`}>
                              {provider.name}
                            </p>
                            <p className="text-sm text-gray-500" data-testid={`text-provider-status-${provider.id}`}>
                              {provider.isActive ? 'Active' : 'Inactive'}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button variant="outline" size="sm" data-testid={`button-sync-${provider.id}`}>
                            <i className="fas fa-sync"></i>
                          </Button>
                          <Button variant="outline" size="sm" data-testid={`button-edit-${provider.id}`}>
                            <i className="fas fa-edit"></i>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8" data-testid="empty-providers">
                    <i className="fas fa-cogs text-4xl text-gray-300 mb-4"></i>
                    <p className="text-gray-500 mb-4">No API providers configured</p>
                    <Button data-testid="button-add-first-provider">
                      <i className="fas fa-plus mr-2"></i>
                      Add Your First Provider
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Service Management */}
            <Card data-testid="card-service-management">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Service Management</CardTitle>
                  <Button className="bg-accent text-white hover:bg-green-700" data-testid="button-sync-all-services">
                    <i className="fas fa-sync mr-2"></i>
                    Sync All
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-3">Quick Actions</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <Button variant="outline" className="h-auto p-3" data-testid="button-manage-categories">
                        <div className="text-center">
                          <i className="fas fa-tags text-gray-500 mb-1 block"></i>
                          <div className="text-sm font-medium">Categories</div>
                        </div>
                      </Button>
                      <Button variant="outline" className="h-auto p-3" data-testid="button-bulk-edit">
                        <div className="text-center">
                          <i className="fas fa-edit text-gray-500 mb-1 block"></i>
                          <div className="text-sm font-medium">Bulk Edit</div>
                        </div>
                      </Button>
                      <Button variant="outline" className="h-auto p-3" data-testid="button-export-services">
                        <div className="text-center">
                          <i className="fas fa-download text-gray-500 mb-1 block"></i>
                          <div className="text-sm font-medium">Export</div>
                        </div>
                      </Button>
                      <Button variant="outline" className="h-auto p-3" data-testid="button-service-reports">
                        <div className="text-center">
                          <i className="fas fa-chart-bar text-gray-500 mb-1 block"></i>
                          <div className="text-sm font-medium">Reports</div>
                        </div>
                      </Button>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-3">System Status</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg" data-testid="status-system">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                          <span className="text-sm text-green-800">System Operational</span>
                        </div>
                        <Badge className="bg-green-100 text-green-800">Online</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg" data-testid="status-sync">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                          <span className="text-sm text-blue-800">Auto-sync Active</span>
                        </div>
                        <Badge className="bg-blue-100 text-blue-800">Running</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
