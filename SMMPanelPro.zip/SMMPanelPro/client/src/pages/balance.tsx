import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Balance() {
  const [amount, setAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const addBalanceMutation = useMutation({
    mutationFn: async (data: { amount: number; paymentMethod: string }) => {
      await apiRequest("POST", "/api/balance", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Balance added successfully!",
      });
      setAmount("");
      setPaymentMethod("");
      // Invalidate user data to refresh balance
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to add balance",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseInt(amount);
    
    if (!numAmount || numAmount < 100) {
      toast({
        title: "Invalid Amount",
        description: "Minimum amount is PKR 100",
        variant: "destructive",
      });
      return;
    }

    if (!paymentMethod) {
      toast({
        title: "Payment Method Required",
        description: "Please select a payment method",
        variant: "destructive",
      });
      return;
    }

    addBalanceMutation.mutate({ amount: numAmount, paymentMethod });
  };

  const selectAmount = (selectedAmount: number) => {
    setAmount(selectedAmount.toString());
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <Header />
        
        <div className="p-6" data-testid="balance-content">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900" data-testid="text-balance-title">
              Add Balance
            </h2>
            <p className="mt-2 text-gray-600" data-testid="text-balance-description">
              Top up your account to place orders.
            </p>
          </div>

          <div className="max-w-2xl">
            <Card data-testid="card-add-balance">
              <CardContent className="p-6">
                <div className="mb-6">
                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Current Balance</p>
                      <p className="text-2xl font-bold text-primary" data-testid="text-current-balance">
                        PKR {user?.balance || "0.00"}
                      </p>
                    </div>
                    <div className="text-4xl text-blue-200">
                      <i className="fas fa-wallet"></i>
                    </div>
                  </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6" data-testid="form-add-balance">
                  <div>
                    <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                      Amount to Add
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 font-medium">
                        PKR
                      </span>
                      <Input
                        type="number"
                        id="amount"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        required
                        min="100"
                        step="10"
                        className="pl-12 text-lg"
                        placeholder="1000"
                        data-testid="input-amount"
                      />
                    </div>
                    <p className="mt-1 text-sm text-gray-500">Minimum amount: PKR 100</p>
                  </div>

                  {/* Quick Amount Buttons */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Quick Select</label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {[500, 1000, 2500, 5000].map((quickAmount) => (
                        <Button
                          key={quickAmount}
                          type="button"
                          variant="outline"
                          className="p-3 h-auto"
                          onClick={() => selectAmount(quickAmount)}
                          data-testid={`button-quick-amount-${quickAmount}`}
                        >
                          <div className="font-semibold">PKR {quickAmount.toLocaleString()}</div>
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="payment-method" className="block text-sm font-medium text-gray-700 mb-2">
                      Payment Method
                    </label>
                    <Select value={paymentMethod} onValueChange={setPaymentMethod} required data-testid="select-payment-method">
                      <SelectTrigger>
                        <SelectValue placeholder="Select Payment Method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="jazzcash">JazzCash</SelectItem>
                        <SelectItem value="easypaisa">EasyPaisa</SelectItem>
                        <SelectItem value="bank">Bank Transfer</SelectItem>
                        <SelectItem value="card">Credit/Debit Card</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4" data-testid="payment-instructions">
                    <div className="flex items-start">
                      <i className="fas fa-info-circle text-yellow-600 mt-0.5 mr-3"></i>
                      <div className="text-sm text-yellow-800">
                        <p className="font-medium mb-1">Payment Instructions:</p>
                        <ul className="list-disc list-inside space-y-1">
                          <li>Payments are processed within 5-10 minutes</li>
                          <li>You will receive a confirmation email once payment is verified</li>
                          <li>For bank transfers, please allow 1-2 hours for processing</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-accent text-white hover:bg-green-700" 
                    size="lg"
                    disabled={addBalanceMutation.isPending}
                    data-testid="button-proceed-payment"
                  >
                    {addBalanceMutation.isPending ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Processing...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-credit-card mr-2"></i>
                        Proceed to Payment
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
