import { useAuth } from "@/hooks/useAuth";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Profile() {
  const { user } = useAuth();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <Header />
        
        <div className="p-6" data-testid="profile-content">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900" data-testid="text-profile-title">
              Profile
            </h2>
            <p className="mt-2 text-gray-600" data-testid="text-profile-description">
              Manage your account settings and preferences.
            </p>
          </div>

          <div className="max-w-2xl space-y-6">
            {/* Profile Information */}
            <Card data-testid="card-profile-info">
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-6 mb-6">
                  <Avatar className="h-20 w-20" data-testid="avatar-profile">
                    <AvatarImage src={user?.profileImageUrl || ""} alt="Profile" />
                    <AvatarFallback className="text-xl">
                      {getInitials(user?.firstName, user?.lastName)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900" data-testid="text-profile-name">
                      {user?.firstName && user?.lastName 
                        ? `${user.firstName} ${user.lastName}`
                        : user?.email?.split('@')[0] || "User"
                      }
                    </h3>
                    <p className="text-gray-600" data-testid="text-profile-email">
                      {user?.email || "No email"}
                    </p>
                    {user?.isAdmin && (
                      <span className="inline-flex px-2 py-1 text-xs font-medium bg-primary text-white rounded-full mt-1" data-testid="badge-admin">
                        Admin
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg" data-testid="info-balance">
                    <div className="text-sm font-medium text-gray-600">Current Balance</div>
                    <div className="text-2xl font-bold text-primary">PKR {user?.balance || "0.00"}</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg" data-testid="info-member-since">
                    <div className="text-sm font-medium text-gray-600">Member Since</div>
                    <div className="text-lg font-semibold text-gray-900">
                      {user?.createdAt ? new Date(user.createdAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      }) : "Unknown"}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Account Actions */}
            <Card data-testid="card-account-actions">
              <CardHeader>
                <CardTitle>Account Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  className="w-full justify-between h-auto p-4" 
                  onClick={() => window.location.href = '/balance'}
                  data-testid="button-add-balance"
                >
                  <div className="flex items-center">
                    <i className="fas fa-credit-card mr-3"></i>
                    <span className="font-medium">Add Balance</span>
                  </div>
                  <i className="fas fa-arrow-right"></i>
                </Button>

                <Button 
                  variant="outline" 
                  className="w-full justify-between h-auto p-4"
                  onClick={() => window.location.href = '/orders'}
                  data-testid="button-view-orders"
                >
                  <div className="flex items-center">
                    <i className="fas fa-list mr-3"></i>
                    <span className="font-medium">View Order History</span>
                  </div>
                  <i className="fas fa-arrow-right"></i>
                </Button>

                {user?.isAdmin && (
                  <Button 
                    variant="outline" 
                    className="w-full justify-between h-auto p-4"
                    onClick={() => window.location.href = '/admin'}
                    data-testid="button-admin-panel"
                  >
                    <div className="flex items-center">
                      <i className="fas fa-cog mr-3"></i>
                      <span className="font-medium">Admin Panel</span>
                    </div>
                    <i className="fas fa-arrow-right"></i>
                  </Button>
                )}

                <Button 
                  variant="destructive" 
                  className="w-full justify-between h-auto p-4"
                  onClick={handleLogout}
                  data-testid="button-logout"
                >
                  <div className="flex items-center">
                    <i className="fas fa-sign-out-alt mr-3"></i>
                    <span className="font-medium">Logout</span>
                  </div>
                  <i className="fas fa-arrow-right"></i>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
