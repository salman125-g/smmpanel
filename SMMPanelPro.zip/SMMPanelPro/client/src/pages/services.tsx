import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import OrderModal from "@/components/order-modal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import type { ServiceWithCategory } from "@shared/schema";

export default function Services() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedService, setSelectedService] = useState<ServiceWithCategory | null>(null);

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
    retry: false,
  });

  const { data: services = [], isLoading } = useQuery({
    queryKey: ["/api/services", selectedCategory === "all" ? undefined : selectedCategory],
    retry: false,
  });

  const filteredServices = services.filter((service: ServiceWithCategory) =>
    service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    service.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getCategoryIcon = (categoryName: string) => {
    const iconMap: Record<string, string> = {
      instagram: "fab fa-instagram",
      facebook: "fab fa-facebook",
      youtube: "fab fa-youtube",
      twitter: "fab fa-twitter",
      tiktok: "fab fa-tiktok",
      linkedin: "fab fa-linkedin",
    };
    return iconMap[categoryName.toLowerCase()] || "fas fa-share-alt";
  };

  const getCategoryColor = (categoryName: string) => {
    const colorMap: Record<string, { bg: string; text: string; icon: string }> = {
      instagram: { bg: "bg-purple-100", text: "text-purple-800", icon: "text-purple-600" },
      facebook: { bg: "bg-blue-100", text: "text-blue-800", icon: "text-blue-600" },
      youtube: { bg: "bg-red-100", text: "text-red-800", icon: "text-red-600" },
      twitter: { bg: "bg-cyan-100", text: "text-cyan-800", icon: "text-cyan-600" },
      tiktok: { bg: "bg-gray-100", text: "text-gray-800", icon: "text-gray-600" },
      linkedin: { bg: "bg-blue-100", text: "text-blue-800", icon: "text-blue-600" },
    };
    return colorMap[categoryName.toLowerCase()] || { bg: "bg-gray-100", text: "text-gray-800", icon: "text-gray-600" };
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <Header />
        
        <div className="p-6" data-testid="services-content">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900" data-testid="text-services-title">
              Services
            </h2>
            <p className="mt-2 text-gray-600" data-testid="text-services-description">
              Browse our comprehensive social media marketing services.
            </p>
          </div>

          {/* Service Categories */}
          <div className="mb-6">
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedCategory === "all" ? "default" : "outline"}
                onClick={() => setSelectedCategory("all")}
                data-testid="button-filter-all"
              >
                All Services
              </Button>
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category.id)}
                  data-testid={`button-filter-${category.slug}`}
                >
                  {category.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Services List */}
          <Card data-testid="card-services-list">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Available Services</CardTitle>
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Search services..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64"
                    data-testid="input-search-services"
                  />
                  <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-6">
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="animate-pulse flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : filteredServices.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Service
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Category
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Rate per 1K
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Min/Max
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Action
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredServices.map((service) => {
                        const colors = service.category ? getCategoryColor(service.category.name) : getCategoryColor("default");
                        const icon = service.category ? getCategoryIcon(service.category.name) : "fas fa-share-alt";
                        
                        return (
                          <tr key={service.id} data-testid={`row-service-${service.id}`}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="flex-shrink-0 h-10 w-10">
                                  <div className={`h-10 w-10 rounded-full ${colors.bg} flex items-center justify-center`}>
                                    <i className={`${icon} ${colors.icon}`}></i>
                                  </div>
                                </div>
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-gray-900" data-testid={`text-service-name-${service.id}`}>
                                    {service.name}
                                  </div>
                                  {service.description && (
                                    <div className="text-sm text-gray-500" data-testid={`text-service-description-${service.id}`}>
                                      {service.description}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {service.category && (
                                <Badge className={`${colors.bg} ${colors.text}`} data-testid={`badge-category-${service.id}`}>
                                  {service.category.name}
                                </Badge>
                              )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium" data-testid={`text-service-rate-${service.id}`}>
                              PKR {service.rate}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500" data-testid={`text-service-limits-${service.id}`}>
                              {service.minQuantity?.toLocaleString()} / {service.maxQuantity?.toLocaleString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Button
                                onClick={() => setSelectedService(service)}
                                data-testid={`button-order-${service.id}`}
                              >
                                Order Now
                              </Button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-12" data-testid="empty-services">
                  <i className="fas fa-search text-4xl text-gray-300 mb-4"></i>
                  <p className="text-gray-500">No services found matching your criteria</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Order Modal */}
      {selectedService && (
        <OrderModal
          service={selectedService}
          isOpen={!!selectedService}
          onClose={() => setSelectedService(null)}
        />
      )}
    </div>
  );
}
