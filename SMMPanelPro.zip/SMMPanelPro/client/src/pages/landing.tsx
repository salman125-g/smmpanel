import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const features = [
    {
      icon: "fas fa-chart-line",
      title: "Instagram Growth",
      description: "High-quality followers, likes, and views for your Instagram account",
    },
    {
      icon: "fab fa-youtube",
      title: "YouTube Boost",
      description: "Real views, subscribers, and engagement for your YouTube channel",
    },
    {
      icon: "fab fa-facebook",
      title: "Facebook Marketing",
      description: "Page likes, post engagement, and organic growth for Facebook",
    },
    {
      icon: "fab fa-tiktok",
      title: "TikTok Viral",
      description: "Views, likes, and followers to make your TikTok content viral",
    },
    {
      icon: "fas fa-shield-alt",
      title: "Safe & Secure",
      description: "100% safe methods that comply with platform guidelines",
    },
    {
      icon: "fas fa-headset",
      title: "24/7 Support",
      description: "Round-the-clock customer support for all your queries",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-primary" data-testid="text-logo">
                SocialBoost Pro
              </h1>
            </div>
            <Button onClick={handleLogin} size="lg" data-testid="button-login">
              Login to Panel
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <Badge variant="secondary" className="mb-4" data-testid="badge-professional">
            Professional SMM Panel
          </Badge>
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6" data-testid="text-hero-title">
            Grow Your Social Media
            <span className="text-primary block">Presence in Pakistan</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto" data-testid="text-hero-description">
            The most trusted SMM panel in Pakistan offering high-quality social media marketing services 
            with competitive PKR pricing and instant delivery.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={handleLogin} className="text-lg px-8 py-3" data-testid="button-get-started">
              Get Started Now
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-3" data-testid="button-view-services">
              View Services
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4" data-testid="text-features-title">
              Why Choose SocialBoost Pro?
            </h3>
            <p className="text-xl text-gray-600" data-testid="text-features-description">
              Premium SMM services designed for the Pakistani market
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow" data-testid={`card-feature-${index}`}>
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <i className={`${feature.icon} text-2xl text-primary`}></i>
                  </div>
                  <CardTitle className="text-xl" data-testid={`text-feature-title-${index}`}>
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base" data-testid={`text-feature-description-${index}`}>
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div data-testid="stat-customers">
              <div className="text-4xl font-bold mb-2">10,000+</div>
              <div className="text-blue-100">Happy Customers</div>
            </div>
            <div data-testid="stat-orders">
              <div className="text-4xl font-bold mb-2">50,000+</div>
              <div className="text-blue-100">Orders Completed</div>
            </div>
            <div data-testid="stat-services">
              <div className="text-4xl font-bold mb-2">200+</div>
              <div className="text-blue-100">Active Services</div>
            </div>
            <div data-testid="stat-uptime">
              <div className="text-4xl font-bold mb-2">99.9%</div>
              <div className="text-blue-100">Uptime</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-3xl font-bold text-gray-900 mb-4" data-testid="text-cta-title">
            Ready to Boost Your Social Media?
          </h3>
          <p className="text-xl text-gray-600 mb-8" data-testid="text-cta-description">
            Join thousands of satisfied customers and start growing your social media presence today.
          </p>
          <Button size="lg" onClick={handleLogin} className="text-lg px-8 py-3" data-testid="button-join-now">
            Join Now - It's Free!
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h4 className="text-2xl font-bold mb-4" data-testid="text-footer-title">
            SocialBoost Pro
          </h4>
          <p className="text-gray-400 mb-4" data-testid="text-footer-description">
            The most trusted SMM panel in Pakistan
          </p>
          <p className="text-sm text-gray-500" data-testid="text-footer-copyright">
            © 2024 SocialBoost Pro. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
