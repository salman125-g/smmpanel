import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { OrderWithDetails } from "@shared/schema";

export default function Orders() {
  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["/api/orders"],
    retry: false,
  });

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: { variant: "secondary", color: "bg-yellow-100 text-yellow-800" },
      processing: { variant: "outline", color: "bg-blue-100 text-blue-800" },
      completed: { variant: "default", color: "bg-green-100 text-green-800" },
      cancelled: { variant: "destructive", color: "bg-red-100 text-red-800" },
    } as const;

    const config = variants[status as keyof typeof variants] || variants.pending;
    
    return (
      <Badge className={config.color}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <Header />
        
        <div className="p-6" data-testid="orders-content">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900" data-testid="text-orders-title">
              My Orders
            </h2>
            <p className="mt-2 text-gray-600" data-testid="text-orders-description">
              Track and manage all your service orders.
            </p>
          </div>

          <Card data-testid="card-orders-list">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Order History</CardTitle>
                <Button onClick={() => window.location.href = '/services'} data-testid="button-place-new-order">
                  <i className="fas fa-plus mr-2"></i>
                  Place New Order
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-6">
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="animate-pulse">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                          <div className="flex-1">
                            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                            <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                          </div>
                          <div className="w-20 h-6 bg-gray-200 rounded"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : orders.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Order Details
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Service
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Quantity
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Total Cost
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {orders.map((order: OrderWithDetails) => (
                        <tr key={order.id} data-testid={`row-order-${order.id}`}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900" data-testid={`text-order-id-${order.id}`}>
                                #{order.id.slice(-8)}
                              </div>
                              <div className="text-sm text-gray-500" data-testid={`text-order-link-${order.id}`}>
                                {order.link.length > 30 ? `${order.link.substring(0, 30)}...` : order.link}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-8 w-8">
                                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                                  <i className="fas fa-share-alt text-primary text-sm"></i>
                                </div>
                              </div>
                              <div className="ml-3">
                                <div className="text-sm font-medium text-gray-900" data-testid={`text-service-name-${order.id}`}>
                                  {order.service.name}
                                </div>
                                {order.service.category && (
                                  <div className="text-sm text-gray-500" data-testid={`text-service-category-${order.id}`}>
                                    {order.service.category.name}
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900" data-testid={`text-order-quantity-${order.id}`}>
                            {order.quantity.toLocaleString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900" data-testid={`text-order-cost-${order.id}`}>
                            PKR {order.totalCost}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap" data-testid={`status-order-${order.id}`}>
                            {getStatusBadge(order.status)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500" data-testid={`text-order-date-${order.id}`}>
                            {formatDate(order.createdAt)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-12" data-testid="empty-orders">
                  <i className="fas fa-shopping-cart text-4xl text-gray-300 mb-4"></i>
                  <p className="text-gray-500 mb-4">No orders found</p>
                  <p className="text-sm text-gray-400 mb-6">
                    Place your first order to get started with our SMM services.
                  </p>
                  <Button onClick={() => window.location.href = '/services'} data-testid="button-place-first-order">
                    <i className="fas fa-plus mr-2"></i>
                    Place Your First Order
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
