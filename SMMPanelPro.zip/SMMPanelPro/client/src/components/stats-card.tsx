interface StatsCardProps {
  icon: string;
  title: string;
  value: string;
  bgColor: string;
  iconColor: string;
  "data-testid"?: string;
}

export default function StatsCard({ icon, title, value, bgColor, iconColor, "data-testid": testId }: StatsCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6" data-testid={testId}>
      <div className="flex items-center">
        <div className="flex-shrink-0">
          <div className={`w-8 h-8 ${bgColor} rounded-md flex items-center justify-center`}>
            <i className={`${icon} ${iconColor}`}></i>
          </div>
        </div>
        <div className="ml-4">
          <p className="text-sm font-medium text-gray-600" data-testid={`${testId}-title`}>
            {title}
          </p>
          <p className="text-2xl font-bold text-gray-900" data-testid={`${testId}-value`}>
            {value}
          </p>
        </div>
      </div>
    </div>
  );
}
