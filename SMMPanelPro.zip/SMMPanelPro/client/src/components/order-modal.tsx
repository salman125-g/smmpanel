import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { ServiceWithCategory } from "@shared/schema";

interface OrderModalProps {
  service: ServiceWithCategory;
  isOpen: boolean;
  onClose: () => void;
}

export default function OrderModal({ service, isOpen, onClose }: OrderModalProps) {
  const [link, setLink] = useState("");
  const [quantity, setQuantity] = useState("");
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const orderMutation = useMutation({
    mutationFn: async (orderData: { serviceId: string; link: string; quantity: number }) => {
      await apiRequest("POST", "/api/orders", orderData);
    },
    onSuccess: () => {
      toast({
        title: "Order Placed Successfully",
        description: "Your order has been placed and is being processed.",
      });
      onClose();
      setLink("");
      setQuantity("");
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats/user"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Order Failed",
        description: error.message || "Failed to place order",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const numQuantity = parseInt(quantity);
    if (!numQuantity || numQuantity < (service.minQuantity || 1) || numQuantity > (service.maxQuantity || 100000)) {
      toast({
        title: "Invalid Quantity",
        description: `Quantity must be between ${service.minQuantity || 1} and ${service.maxQuantity || 100000}`,
        variant: "destructive",
      });
      return;
    }

    if (!link.trim()) {
      toast({
        title: "Link Required",
        description: "Please provide a valid link",
        variant: "destructive",
      });
      return;
    }

    // Calculate total cost
    const rate = parseFloat(service.rate);
    const totalCost = (numQuantity / 1000) * rate;
    const userBalance = parseFloat(user?.balance || "0");

    if (userBalance < totalCost) {
      toast({
        title: "Insufficient Balance",
        description: `You need PKR ${totalCost.toFixed(2)} but only have PKR ${userBalance.toFixed(2)}`,
        variant: "destructive",
      });
      return;
    }

    orderMutation.mutate({
      serviceId: service.id,
      link: link.trim(),
      quantity: numQuantity,
    });
  };

  const getCategoryIcon = (categoryName: string) => {
    const iconMap: Record<string, string> = {
      instagram: "fab fa-instagram",
      facebook: "fab fa-facebook",
      youtube: "fab fa-youtube",
      twitter: "fab fa-twitter",
      tiktok: "fab fa-tiktok",
    };
    return iconMap[categoryName.toLowerCase()] || "fas fa-share-alt";
  };

  const getCategoryColor = (categoryName: string) => {
    const colorMap: Record<string, { bg: string; icon: string }> = {
      instagram: { bg: "bg-purple-100", icon: "text-purple-600" },
      facebook: { bg: "bg-blue-100", icon: "text-blue-600" },
      youtube: { bg: "bg-red-100", icon: "text-red-600" },
      twitter: { bg: "bg-cyan-100", icon: "text-cyan-600" },
      tiktok: { bg: "bg-gray-100", icon: "text-gray-600" },
    };
    return colorMap[categoryName.toLowerCase()] || { bg: "bg-gray-100", icon: "text-gray-600" };
  };

  const calculateTotal = () => {
    const numQuantity = parseInt(quantity) || 0;
    const rate = parseFloat(service.rate);
    return (numQuantity / 1000) * rate;
  };

  const colors = service.category ? getCategoryColor(service.category.name) : getCategoryColor("default");
  const icon = service.category ? getCategoryIcon(service.category.name) : "fas fa-share-alt";

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md" data-testid="modal-order">
        <DialogHeader>
          <DialogTitle data-testid="text-order-modal-title">Place Order</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6" data-testid="form-place-order">
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2 block">Selected Service</Label>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10">
                  <div className={`h-10 w-10 rounded-full ${colors.bg} flex items-center justify-center`}>
                    <i className={`${icon} ${colors.icon}`}></i>
                  </div>
                </div>
                <div className="ml-4">
                  <div className="text-sm font-medium text-gray-900" data-testid="text-selected-service-name">
                    {service.name}
                  </div>
                  <div className="text-sm text-gray-500" data-testid="text-selected-service-rate">
                    Rate: PKR {service.rate} per 1K
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div>
            <Label htmlFor="link" className="text-sm font-medium text-gray-700 mb-2 block">
              Link
            </Label>
            <Input
              type="url"
              id="link"
              value={link}
              onChange={(e) => setLink(e.target.value)}
              required
              placeholder="https://instagram.com/username"
              data-testid="input-order-link"
            />
          </div>

          <div>
            <Label htmlFor="quantity" className="text-sm font-medium text-gray-700 mb-2 block">
              Quantity
            </Label>
            <Input
              type="number"
              id="quantity"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              required
              min={service.minQuantity || 1}
              max={service.maxQuantity || 100000}
              placeholder="1000"
              data-testid="input-order-quantity"
            />
            <p className="mt-1 text-sm text-gray-500">
              Min: {service.minQuantity?.toLocaleString() || 1} - Max: {service.maxQuantity?.toLocaleString() || 100000}
            </p>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg" data-testid="order-summary">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-gray-700">Total Cost:</span>
              <span className="text-lg font-bold text-primary" data-testid="text-total-cost">
                PKR {calculateTotal().toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center mt-2">
              <span className="text-sm text-gray-600">Your Balance:</span>
              <span className="text-sm font-medium text-gray-900" data-testid="text-user-balance">
                PKR {user?.balance || "0.00"}
              </span>
            </div>
          </div>

          <div className="flex space-x-4">
            <Button 
              type="button" 
              variant="outline" 
              className="flex-1" 
              onClick={onClose}
              data-testid="button-cancel-order"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="flex-1"
              disabled={orderMutation.isPending}
              data-testid="button-submit-order"
            >
              {orderMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Placing...
                </>
              ) : (
                "Place Order"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
