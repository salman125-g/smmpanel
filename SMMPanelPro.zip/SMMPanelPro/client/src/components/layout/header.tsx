import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Header() {
  const { user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50" data-testid="header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold text-primary lg:hidden" data-testid="text-mobile-logo">
                SocialBoost Pro
              </h1>
            </div>
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-4">
                <a href="/" className="text-gray-900 hover:text-primary px-3 py-2 rounded-md text-sm font-medium" data-testid="nav-desktop-dashboard">
                  Dashboard
                </a>
                <a href="/services" className="text-gray-500 hover:text-primary px-3 py-2 rounded-md text-sm font-medium" data-testid="nav-desktop-services">
                  Services
                </a>
                <a href="/orders" className="text-gray-500 hover:text-primary px-3 py-2 rounded-md text-sm font-medium" data-testid="nav-desktop-orders">
                  Orders
                </a>
                <a href="/balance" className="text-gray-500 hover:text-primary px-3 py-2 rounded-md text-sm font-medium" data-testid="nav-desktop-balance">
                  Add Balance
                </a>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-700" data-testid="balance-display">
              Balance: <span className="font-semibold text-accent">PKR {user?.balance || "0.00"}</span>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2 hover:bg-gray-50" data-testid="button-user-menu">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.profileImageUrl || ""} alt="User avatar" />
                    <AvatarFallback>
                      {getInitials(user?.firstName, user?.lastName)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden md:block text-sm" data-testid="text-user-name">
                    {user?.firstName && user?.lastName 
                      ? `${user.firstName} ${user.lastName}`
                      : user?.email?.split('@')[0] || "User"
                    }
                  </span>
                  <i className="fas fa-chevron-down text-xs"></i>
                </Button>
              </DropdownMenuTrigger>
              
              <DropdownMenuContent align="end" className="w-56" data-testid="dropdown-user-menu">
                <DropdownMenuItem onClick={() => window.location.href = '/profile'} data-testid="menu-profile">
                  <i className="fas fa-user mr-2"></i>
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => window.location.href = '/balance'} data-testid="menu-add-balance">
                  <i className="fas fa-wallet mr-2"></i>
                  Add Balance
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => window.location.href = '/orders'} data-testid="menu-orders">
                  <i className="fas fa-list mr-2"></i>
                  My Orders
                </DropdownMenuItem>
                {user?.isAdmin && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => window.location.href = '/admin'} data-testid="menu-admin">
                      <i className="fas fa-cog mr-2"></i>
                      Admin Panel
                    </DropdownMenuItem>
                  </>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600" data-testid="menu-logout">
                  <i className="fas fa-sign-out-alt mr-2"></i>
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Mobile Menu Button */}
      <div className="lg:hidden fixed bottom-4 right-4 z-50">
        <Button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="bg-primary text-white p-3 rounded-full shadow-lg"
          data-testid="button-mobile-menu"
        >
          <i className="fas fa-bars"></i>
        </Button>
      </div>
    </nav>
  );
}
