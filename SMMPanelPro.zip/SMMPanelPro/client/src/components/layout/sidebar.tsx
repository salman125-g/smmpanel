import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const navItems = [
    { href: "/", icon: "fas fa-tachometer-alt", label: "Dashboard" },
    { href: "/services", icon: "fas fa-list", label: "Services" },
    { href: "/orders", icon: "fas fa-shopping-cart", label: "My Orders" },
    { href: "/balance", icon: "fas fa-wallet", label: "Add Balance" },
    { href: "/profile", icon: "fas fa-user", label: "Profile" },
  ];

  if (user?.isAdmin) {
    navItems.push({ href: "/admin", icon: "fas fa-cog", label: "Admin Panel" });
  }

  return (
    <aside className="hidden lg:flex lg:flex-shrink-0" data-testid="sidebar">
      <div className="flex flex-col w-64 bg-white border-r border-gray-200">
        <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
          <nav className="mt-5 flex-1 px-2 space-y-1">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <a
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors",
                    isActive
                      ? "bg-primary text-white"
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                  )}
                  data-testid={`nav-${item.href.slice(1) || 'dashboard'}`}
                >
                  <i className={`${item.icon} mr-3`}></i>
                  {item.label}
                </a>
              );
            })}
          </nav>
        </div>
      </div>
    </aside>
  );
}
