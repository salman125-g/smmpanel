import {
  users,
  categories,
  apiProviders,
  services,
  orders,
  balanceTransactions,
  type User,
  type UpsertUser,
  type Category,
  type InsertCategory,
  type ApiProvider,
  type InsertApiProvider,
  type Service,
  type InsertService,
  type ServiceWithCategory,
  type Order,
  type InsertOrder,
  type OrderWithDetails,
  type BalanceTransaction,
  type InsertBalanceTransaction,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, ilike, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserBalance(userId: string, amount: string): Promise<void>;

  // Category operations
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;

  // API Provider operations
  getApiProviders(): Promise<ApiProvider[]>;
  createApiProvider(provider: InsertApiProvider): Promise<ApiProvider>;
  updateApiProvider(id: string, provider: Partial<InsertApiProvider>): Promise<ApiProvider>;

  // Service operations
  getServices(categoryId?: string): Promise<ServiceWithCategory[]>;
  getServiceById(id: string): Promise<ServiceWithCategory | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: string, service: Partial<InsertService>): Promise<Service>;
  syncServicesFromProvider(providerId: string, serviceData: any[]): Promise<void>;

  // Order operations
  createOrder(order: InsertOrder): Promise<Order>;
  getOrdersByUser(userId: string): Promise<OrderWithDetails[]>;
  getOrderById(id: string): Promise<OrderWithDetails | undefined>;
  updateOrderStatus(id: string, status: string, externalOrderId?: string): Promise<void>;
  getAllOrders(): Promise<OrderWithDetails[]>;

  // Balance operations
  createBalanceTransaction(transaction: InsertBalanceTransaction): Promise<BalanceTransaction>;
  getBalanceTransactions(userId: string): Promise<BalanceTransaction[]>;

  // Stats
  getUserStats(userId: string): Promise<{
    totalOrders: number;
    pendingOrders: number;
    completedOrders: number;
    totalSpent: string;
  }>;

  getAdminStats(): Promise<{
    totalUsers: number;
    activeServices: number;
    apiProviders: number;
    pendingOrders: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserBalance(userId: string, amount: string): Promise<void> {
    await db
      .update(users)
      .set({
        balance: sql`balance + ${amount}`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(categories.sortOrder, categories.name);
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  async getApiProviders(): Promise<ApiProvider[]> {
    return await db.select().from(apiProviders).orderBy(apiProviders.name);
  }

  async createApiProvider(provider: InsertApiProvider): Promise<ApiProvider> {
    const [newProvider] = await db.insert(apiProviders).values(provider).returning();
    return newProvider;
  }

  async updateApiProvider(id: string, provider: Partial<InsertApiProvider>): Promise<ApiProvider> {
    const [updatedProvider] = await db
      .update(apiProviders)
      .set(provider)
      .where(eq(apiProviders.id, id))
      .returning();
    return updatedProvider;
  }

  async getServices(categoryId?: string): Promise<ServiceWithCategory[]> {
    const query = db
      .select({
        id: services.id,
        categoryId: services.categoryId,
        apiProviderId: services.apiProviderId,
        externalId: services.externalId,
        name: services.name,
        description: services.description,
        rate: services.rate,
        minQuantity: services.minQuantity,
        maxQuantity: services.maxQuantity,
        isActive: services.isActive,
        createdAt: services.createdAt,
        updatedAt: services.updatedAt,
        category: categories,
      })
      .from(services)
      .leftJoin(categories, eq(services.categoryId, categories.id))
      .where(eq(services.isActive, true));

    if (categoryId) {
      query.where(and(eq(services.isActive, true), eq(services.categoryId, categoryId)));
    }

    return await query.orderBy(services.name);
  }

  async getServiceById(id: string): Promise<ServiceWithCategory | undefined> {
    const [service] = await db
      .select({
        id: services.id,
        categoryId: services.categoryId,
        apiProviderId: services.apiProviderId,
        externalId: services.externalId,
        name: services.name,
        description: services.description,
        rate: services.rate,
        minQuantity: services.minQuantity,
        maxQuantity: services.maxQuantity,
        isActive: services.isActive,
        createdAt: services.createdAt,
        updatedAt: services.updatedAt,
        category: categories,
      })
      .from(services)
      .leftJoin(categories, eq(services.categoryId, categories.id))
      .where(eq(services.id, id));

    return service;
  }

  async createService(service: InsertService): Promise<Service> {
    const [newService] = await db.insert(services).values(service).returning();
    return newService;
  }

  async updateService(id: string, service: Partial<InsertService>): Promise<Service> {
    const [updatedService] = await db
      .update(services)
      .set({ ...service, updatedAt: new Date() })
      .where(eq(services.id, id))
      .returning();
    return updatedService;
  }

  async syncServicesFromProvider(providerId: string, serviceData: any[]): Promise<void> {
    // This would implement syncing services from external API providers
    // For now, we'll implement a basic version
    for (const serviceItem of serviceData) {
      await db
        .insert(services)
        .values({
          apiProviderId: providerId,
          externalId: serviceItem.service.toString(),
          name: serviceItem.name,
          rate: serviceItem.rate,
          minQuantity: serviceItem.min,
          maxQuantity: serviceItem.max,
          categoryId: serviceItem.category, // Would need mapping logic
        })
        .onConflictDoUpdate({
          target: [services.apiProviderId, services.externalId],
          set: {
            name: serviceItem.name,
            rate: serviceItem.rate,
            minQuantity: serviceItem.min,
            maxQuantity: serviceItem.max,
            updatedAt: new Date(),
          },
        });
    }
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }

  async getOrdersByUser(userId: string): Promise<OrderWithDetails[]> {
    return await db
      .select({
        id: orders.id,
        userId: orders.userId,
        serviceId: orders.serviceId,
        apiProviderId: orders.apiProviderId,
        externalOrderId: orders.externalOrderId,
        link: orders.link,
        quantity: orders.quantity,
        totalCost: orders.totalCost,
        status: orders.status,
        startCount: orders.startCount,
        remainingQuantity: orders.remainingQuantity,
        createdAt: orders.createdAt,
        updatedAt: orders.updatedAt,
        service: {
          id: services.id,
          categoryId: services.categoryId,
          apiProviderId: services.apiProviderId,
          externalId: services.externalId,
          name: services.name,
          description: services.description,
          rate: services.rate,
          minQuantity: services.minQuantity,
          maxQuantity: services.maxQuantity,
          isActive: services.isActive,
          createdAt: services.createdAt,
          updatedAt: services.updatedAt,
          category: categories,
        },
        user: users,
      })
      .from(orders)
      .leftJoin(services, eq(orders.serviceId, services.id))
      .leftJoin(categories, eq(services.categoryId, categories.id))
      .leftJoin(users, eq(orders.userId, users.id))
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async getOrderById(id: string): Promise<OrderWithDetails | undefined> {
    const [order] = await db
      .select({
        id: orders.id,
        userId: orders.userId,
        serviceId: orders.serviceId,
        apiProviderId: orders.apiProviderId,
        externalOrderId: orders.externalOrderId,
        link: orders.link,
        quantity: orders.quantity,
        totalCost: orders.totalCost,
        status: orders.status,
        startCount: orders.startCount,
        remainingQuantity: orders.remainingQuantity,
        createdAt: orders.createdAt,
        updatedAt: orders.updatedAt,
        service: {
          id: services.id,
          categoryId: services.categoryId,
          apiProviderId: services.apiProviderId,
          externalId: services.externalId,
          name: services.name,
          description: services.description,
          rate: services.rate,
          minQuantity: services.minQuantity,
          maxQuantity: services.maxQuantity,
          isActive: services.isActive,
          createdAt: services.createdAt,
          updatedAt: services.updatedAt,
          category: categories,
        },
        user: users,
      })
      .from(orders)
      .leftJoin(services, eq(orders.serviceId, services.id))
      .leftJoin(categories, eq(services.categoryId, categories.id))
      .leftJoin(users, eq(orders.userId, users.id))
      .where(eq(orders.id, id));

    return order;
  }

  async updateOrderStatus(id: string, status: string, externalOrderId?: string): Promise<void> {
    await db
      .update(orders)
      .set({
        status,
        externalOrderId,
        updatedAt: new Date(),
      })
      .where(eq(orders.id, id));
  }

  async getAllOrders(): Promise<OrderWithDetails[]> {
    return await db
      .select({
        id: orders.id,
        userId: orders.userId,
        serviceId: orders.serviceId,
        apiProviderId: orders.apiProviderId,
        externalOrderId: orders.externalOrderId,
        link: orders.link,
        quantity: orders.quantity,
        totalCost: orders.totalCost,
        status: orders.status,
        startCount: orders.startCount,
        remainingQuantity: orders.remainingQuantity,
        createdAt: orders.createdAt,
        updatedAt: orders.updatedAt,
        service: {
          id: services.id,
          categoryId: services.categoryId,
          apiProviderId: services.apiProviderId,
          externalId: services.externalId,
          name: services.name,
          description: services.description,
          rate: services.rate,
          minQuantity: services.minQuantity,
          maxQuantity: services.maxQuantity,
          isActive: services.isActive,
          createdAt: services.createdAt,
          updatedAt: services.updatedAt,
          category: categories,
        },
        user: users,
      })
      .from(orders)
      .leftJoin(services, eq(orders.serviceId, services.id))
      .leftJoin(categories, eq(services.categoryId, categories.id))
      .leftJoin(users, eq(orders.userId, users.id))
      .orderBy(desc(orders.createdAt));
  }

  async createBalanceTransaction(transaction: InsertBalanceTransaction): Promise<BalanceTransaction> {
    const [newTransaction] = await db.insert(balanceTransactions).values(transaction).returning();
    return newTransaction;
  }

  async getBalanceTransactions(userId: string): Promise<BalanceTransaction[]> {
    return await db
      .select()
      .from(balanceTransactions)
      .where(eq(balanceTransactions.userId, userId))
      .orderBy(desc(balanceTransactions.createdAt));
  }

  async getUserStats(userId: string): Promise<{
    totalOrders: number;
    pendingOrders: number;
    completedOrders: number;
    totalSpent: string;
  }> {
    const [stats] = await db
      .select({
        totalOrders: sql<number>`count(*)`,
        pendingOrders: sql<number>`count(*) filter (where status in ('pending', 'processing'))`,
        completedOrders: sql<number>`count(*) filter (where status = 'completed')`,
        totalSpent: sql<string>`coalesce(sum(total_cost), 0)`,
      })
      .from(orders)
      .where(eq(orders.userId, userId));

    return stats || { totalOrders: 0, pendingOrders: 0, completedOrders: 0, totalSpent: "0" };
  }

  async getAdminStats(): Promise<{
    totalUsers: number;
    activeServices: number;
    apiProviders: number;
    pendingOrders: number;
  }> {
    const [userCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
    const [serviceCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(services)
      .where(eq(services.isActive, true));
    const [providerCount] = await db.select({ count: sql<number>`count(*)` }).from(apiProviders);
    const [pendingCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(orders)
      .where(sql`status in ('pending', 'processing')`);

    return {
      totalUsers: userCount.count || 0,
      activeServices: serviceCount.count || 0,
      apiProviders: providerCount.count || 0,
      pendingOrders: pendingCount.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
