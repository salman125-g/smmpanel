import React from 'react';
import { Clock, Check, AlertTriangle, Star } from 'lucide-react';
import type { Service } from '../types';

interface ServiceCardProps {
  service: Service;
  onOrder: (service: Service) => void;
}

export default function ServiceCard({ service, onOrder }: ServiceCardProps) {
  const qualityColor = {
    Basic: 'text-gray-600 bg-gray-100',
    Premium: 'text-blue-600 bg-blue-100',
    Ultra: 'text-purple-600 bg-purple-100'
  }[service.quality];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg font-semibold text-gray-900">{service.name}</h3>
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${qualityColor}`}>
          {service.quality}
        </span>
      </div>
      <p className="text-sm text-gray-600 mb-4">{service.description}</p>
      
      <div className="space-y-3 mb-4">
        <div className="flex items-center text-sm text-gray-600">
          <Clock className="h-4 w-4 mr-2 text-indigo-500" />
          <span>Delivery Time: {service.averageTime}</span>
        </div>
        <div className="space-y-2">
          {service.features.map((feature, index) => (
            <div key={index} className="flex items-start text-sm">
              <Check className="h-4 w-4 mr-2 text-green-500 flex-shrink-0 mt-0.5" />
              <span className="text-gray-600">{feature}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
        <div>
          <span className="text-2xl font-bold text-indigo-600">${service.price}</span>
          <span className="text-sm text-gray-500 ml-1">per {service.minQuantity}</span>
        </div>
        <button
          onClick={() => onOrder(service)}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
        >
          Order Now
        </button>
      </div>

      <div className="mt-4 flex items-start space-x-2 text-xs bg-gray-50 rounded-lg p-2">
        <AlertTriangle className="h-4 w-4 text-gray-400 flex-shrink-0" />
        <p className="text-gray-500">Quantity: {service.minQuantity} - {service.maxQuantity}</p>
      </div>
    </div>
  );
}