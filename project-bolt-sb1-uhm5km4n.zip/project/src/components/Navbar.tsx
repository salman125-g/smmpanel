import React from 'react';
import { User, Wallet, ShoppingCart, LayoutDashboard, Settings, HelpCircle, LogOut, List, Grid } from 'lucide-react';

export default function Navbar() {
  return (
    <div className="bg-white shadow-lg">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between h-16 px-4 sm:px-6 lg:px-8">
          <div className="flex items-center">
            <span className="text-2xl font-bold text-indigo-600">SLK Panel</span>
            <div className="hidden md:flex ml-10 space-x-6">
              <NavLink icon={LayoutDashboard} text="Dashboard" active />
              <NavLink icon={ShoppingCart} text="Services" />
              <NavLink icon={ShoppingCart} text="Mass Order" />
              <NavLink icon={HelpCircle} text="Support" />
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center bg-green-50 px-4 py-2 rounded-lg">
              <Wallet className="h-5 w-5 text-green-600 mr-2" />
              <span className="text-green-600 font-medium">$50.00</span>
            </div>
            <div className="relative group">
              <button className="flex items-center text-gray-600 hover:text-indigo-600 transition-colors">
                <User className="h-6 w-6" />
              </button>
              <div className="absolute right-0 w-48 mt-2 bg-white rounded-lg shadow-lg py-1 hidden group-hover:block">
                <UserMenuItem icon={User} text="Profile" />
                <UserMenuItem icon={Settings} text="Settings" />
                <UserMenuItem icon={LogOut} text="Logout" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function NavLink({ icon: Icon, text, active = false }: { icon: any, text: string, active?: boolean }) {
  return (
    <a
      href="#"
      className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
        active
          ? 'text-indigo-600 bg-indigo-50'
          : 'text-gray-600 hover:text-indigo-600 hover:bg-indigo-50'
      }`}
    >
      <Icon className="h-5 w-5 mr-2" />
      {text}
    </a>
  );
}

function UserMenuItem({ icon: Icon, text }: { icon: any, text: string }) {
  return (
    <a
      href="#"
      className="block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
    >
      <div className="flex items-center">
        <Icon className="h-4 w-4 mr-2" />
        {text}
      </div>
    </a>
  );
}