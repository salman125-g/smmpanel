export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  minQuantity: number;
  maxQuantity: number;
  averageTime: string;
  quality: 'Basic' | 'Premium' | 'Ultra';
  features: string[];
}

export interface Order {
  id: string;
  serviceId: string;
  quantity: number;
  link: string;
  status: 'pending' | 'processing' | 'completed' | 'cancelled';
  createdAt: string;
  startCount?: number;
  remains?: number;
  charge: number;
}

export interface User {
  id: string;
  email: string;
  balance: number;
  totalSpent: number;
  totalOrders: number;
  apiKey?: string;
}

export interface MassOrder {
  serviceId: string;
  quantity: number;
  links: string[];
}