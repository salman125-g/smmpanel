import React, { useState } from 'react';
import { Instagram, Facebook, Twitter, Youtube, BookText, Twitch, List, Grid, Star, Clock, Shield, Zap } from 'lucide-react';
import Navbar from './components/Navbar';
import ServiceCard from './components/ServiceCard';
import OrderModal from './components/OrderModal';
import type { Service } from './types';

const SERVICES: Service[] = [
  {
    id: '1',
    name: 'Instagram Followers',
    description: 'Real & Active Instagram Followers | 30 Days Refill',
    price: 2.99,
    category: 'Instagram',
    minQuantity: 100,
    maxQuantity: 10000,
    averageTime: '0-3 hours',
    quality: 'Premium',
    features: [
      'Real & Active Followers',
      'Instant Start',
      'No Password Required',
      '30 Days Refill Guarantee'
    ]
  },
  {
    id: '2',
    name: 'Instagram Likes',
    description: 'High Quality Instagram Likes | Instant',
    price: 0.99,
    category: 'Instagram',
    minQuantity: 50,
    maxQuantity: 25000,
    averageTime: '0-1 hour',
    quality: 'Ultra',
    features: [
      'High-Quality Likes',
      'Instant Delivery',
      'Natural Delivery',
      'No Password Needed'
    ]
  },
  {
    id: '3',
    name: 'Instagram Views',
    description: 'Instagram Views | Fast Delivery',
    price: 0.10,
    category: 'Instagram',
    minQuantity: 1000,
    maxQuantity: 1000000,
    averageTime: '0-1 hour',
    quality: 'Premium',
    features: [
      'High Retention',
      'Instant Start',
      'Natural Delivery',
      'No Drop'
    ]
  },
  {
    id: '4',
    name: 'TikTok Followers',
    description: 'Real TikTok Followers | HQ',
    price: 4.99,
    category: 'TikTok',
    minQuantity: 100,
    maxQuantity: 50000,
    averageTime: '1-2 days',
    quality: 'Ultra',
    features: [
      'Active Followers',
      'Instant Start',
      'No Password Needed',
      '30 Days Warranty'
    ]
  },
  {
    id: '5',
    name: 'YouTube Views',
    description: 'YouTube Views | High Retention',
    price: 1.50,
    category: 'YouTube',
    minQuantity: 1000,
    maxQuantity: 100000,
    averageTime: '1-2 days',
    quality: 'Premium',
    features: [
      'High Retention',
      'Real Views',
      'Safe Method',
      'Lifetime Guarantee'
    ]
  },
  {
    id: '6',
    name: 'Facebook Page Likes',
    description: 'Facebook Page Likes | Non-Drop',
    price: 3.99,
    category: 'Facebook',
    minQuantity: 500,
    maxQuantity: 50000,
    averageTime: '1-3 days',
    quality: 'Ultra',
    features: [
      'Real Page Likes',
      'Non-Drop Likes',
      'Active Profiles',
      'Lifetime Warranty'
    ]
  }
];

const CATEGORIES = [
  { id: 'all', name: 'All Services', icon: null },
  { id: 'Instagram', name: 'Instagram', icon: Instagram },
  { id: 'Facebook', name: 'Facebook', icon: Facebook },
  { id: 'Twitter', name: 'Twitter', icon: Twitter },
  { id: 'YouTube', name: 'YouTube', icon: Youtube },
  { id: 'TikTok', name: 'TikTok', icon: BookText },
  { id: 'Twitch', name: 'Twitch', icon: Twitch }
];

function App() {
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');

  const handleOrder = (service: Service) => {
    setSelectedService(service);
  };

  const handleCloseModal = () => {
    setSelectedService(null);
  };

  const handleSubmitOrder = (quantity: number, link: string) => {
    console.log('Order placed:', { service: selectedService, quantity, link });
    setSelectedService(null);
  };

  const filteredServices = SERVICES.filter(service => {
    const matchesCategory = activeCategory === 'all' || service.category === activeCategory;
    const matchesSearch = service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Welcome to SLK Panel</h1>
          <p className="mt-2 text-gray-600">The best SMM panel for your social media growth</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="bg-indigo-100 rounded-full p-3">
                <Star className="h-6 w-6 text-indigo-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-gray-900">Best Quality</h3>
                <p className="text-sm text-gray-500">Premium social media services</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="bg-green-100 rounded-full p-3">
                <Clock className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-gray-900">Fast Delivery</h3>
                <p className="text-sm text-gray-500">Quick start & instant delivery</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="bg-blue-100 rounded-full p-3">
                <Shield className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-gray-900">Safe & Secure</h3>
                <p className="text-sm text-gray-500">100% safe payment methods</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="bg-purple-100 rounded-full p-3">
                <Zap className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-gray-900">24/7 Support</h3>
                <p className="text-sm text-gray-500">Always here to help you</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map(category => (
                <button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                    activeCategory === category.id
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {category.icon && <category.icon className="h-5 w-5 mr-2" />}
                  {category.name}
                </button>
              ))}
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded transition-colors ${viewMode === 'grid' ? 'bg-white text-indigo-600 shadow' : 'text-gray-600'}`}
                >
                  <Grid className="h-5 w-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded transition-colors ${viewMode === 'list' ? 'bg-white text-indigo-600 shadow' : 'text-gray-600'}`}
                >
                  <List className="h-5 w-5" />
                </button>
              </div>
              <div className="w-64">
                <input
                  type="text"
                  placeholder="Search services..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-2 bg-gray-100 border-none rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>
        </div>

        {viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.map((service) => (
              <ServiceCard
                key={service.id}
                service={service}
                onOrder={handleOrder}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Min/Max</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quality</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredServices.map((service) => (
                  <tr key={service.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="text-sm font-medium text-gray-900">{service.name}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-500">{service.description}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">
                        {service.minQuantity} - {service.maxQuantity}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        ${service.price}/{service.minQuantity}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        service.quality === 'Premium' ? 'bg-blue-100 text-blue-800' :
                        service.quality === 'Ultra' ? 'bg-purple-100 text-purple-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {service.quality}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleOrder(service)}
                        className="text-indigo-600 hover:text-indigo-900 transition-colors"
                      >
                        Order Now
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {filteredServices.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No services found matching your criteria.</p>
          </div>
        )}
      </main>

      {selectedService && (
        <OrderModal
          service={selectedService}
          onClose={handleCloseModal}
          onSubmit={handleSubmitOrder}
        />
      )}
    </div>
  );
}

export default App;